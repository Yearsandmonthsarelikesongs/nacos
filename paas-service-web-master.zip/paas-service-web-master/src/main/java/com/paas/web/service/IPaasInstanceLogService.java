package com.paas.web.service;

import com.paas.web.domain.PaasInstanceLog;

public interface IPaasInstanceLogService {
    public Integer insert(PaasInstanceLog log);
}
